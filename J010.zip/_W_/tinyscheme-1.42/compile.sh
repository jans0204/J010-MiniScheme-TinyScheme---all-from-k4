# compile.sh

make > compile.log 2>&1
ranlib libtinyscheme.a
nm -s libtinyscheme.a > libtinyscheme.idx

